# Security Model

TBD — authentication, authorization, TLS, secrets, IAM, WAF, and logging.
