# Architecture

TBD — establish the selected end-to-end architecture after validating the provider-managed runtime connectivity model.
